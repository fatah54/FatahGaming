<?php
include 'ip.php';
header('Location: /index.html');
exit
?>
