######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Zumbailee,Febry, Bima, Accil, Alfa #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest                        #
######################################
z="
";vBz='{u}$';ABz='m}║$';sBz='AN $';Az='a="\';uBz='   $';cBz='} <═';Cz='30;1';MBz='LS $';Xz='[39;';nBz='p}HA';bBz='}${n';Vz='[38;';FBz='{m}║';ICz='gout';Dz='m"';rBz=' TEM';QBz='}STA';JCz=' ${b';gBz='   ╔';FCz='═╗"';ACz='h}╚═';sz='"';Rz='1m"';Bz='033[';RBz='TUS ';YBz='{o}═';Qz='[36;';uz='echo';VBz='m}╚═';CBz='${p}';iz='v="\';bz='r';Lz='34;1';DBz='NO${';Uz='m1="';mBz='║ ${';Mz='c="\';BCz='═══╝';NBz='{h}}';hz='m║"';Kz='b="\';Tz='37;1';Wz='p2="';Sz='p="\';ZBz='═══>';fz='m╗"';XBz='{n}$';CCz='╚═══';EBz='h}}$';xz='═══╗';LBz=' TOO';yBz='{u}"';jz='z="$';dz='m╔"';KCz='═╝"';IBz='h}{ ';Ez='m="\';qz='x="$';wBz='{h} ';tBz='{b}║';lz='════';pz='j="$';aBz=' ${o';gz='u="\';ez='t="\';iBz='h}║ ';yz='╔═══';HBz='  ${';rz='o="╚';fBz='${b}';GBz='${v}';hBz='╗"';Oz='pu="';Iz='k="\';cz='s="\';wz='m}╔═';OBz='v}${';kz='{b}═';lBz='{h}║';qBz='RGET';kBz='01 $';xBz='ON $';nz='q="$';UBz='}║"';PBz=' ${p';oz='═══"';HCz='m}Lo';WBz='═══$';Zz='[40;';Fz='31;1';BBz='{h}{';dBz='{n}"';ECz='{x}$';pBz='B NA';JBz='KUMP';mz='═"';Hz='32;1';Pz='\033';DCz='{o}$';az='clea';eBz='h}╔═';KBz='ULAN';GCz='00 $';Yz='hi="';Gz='h="\';jBz='${m}';TBz='}${m';SBz='${h}';Jz='33;1';tz='n="╝';vz=' "${';Nz='35;1';oBz='CK F';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Bz$Tz$Dz$z$Uz$Pz$Vz$Rz$z$Wz$Pz$Xz$Rz$z$Yz$Pz$Zz$Rz$z$az$bz$z$cz$Bz$Lz$dz$z$ez$Bz$Lz$fz$z$gz$Bz$Lz$hz$z$iz$Bz$Fz$hz$z$jz$kz$lz$lz$lz$lz$lz$mz$z$nz$kz$oz$z$pz$kz$lz$lz$mz$z$qz$kz$oz$z$rz$sz$z$tz$sz$z$az$bz$z$uz$vz$wz$xz$yz$lz$lz$lz$lz$xz$yz$lz$xz$sz$z$uz$vz$ABz$BBz$CBz$DBz$EBz$FBz$GBz$HBz$IBz$CBz$JBz$KBz$LBz$MBz$NBz$HBz$OBz$ABz$BBz$PBz$QBz$RBz$SBz$TBz$UBz$z$uz$vz$VBz$WBz$XBz$YBz$lz$lz$lz$lz$ZBz$aBz$bBz$cBz$lz$WBz$dBz$z$uz$z$uz$vz$eBz$xz$fBz$yz$lz$lz$lz$lz$xz$gBz$lz$hBz$z$uz$vz$iBz$jBz$kBz$lBz$fBz$mBz$nBz$oBz$pBz$qBz$rBz$sBz$tBz$uBz$vBz$wBz$xBz$yBz$z$uz$vz$ACz$BCz$fBz$CCz$lz$lz$lz$lz$BCz$uBz$DCz$ECz$dBz$z$uz$z$uz$vz$eBz$xz$fBz$yz$lz$FCz$z$uz$vz$iBz$jBz$GCz$lBz$fBz$mBz$HCz$ICz$JCz$UBz$z$uz$vz$ACz$BCz$fBz$CCz$lz$KCz" 
