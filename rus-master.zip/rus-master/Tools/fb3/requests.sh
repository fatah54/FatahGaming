apt update && apt upgrade
pkg install figlet
pkg install toilet
pkg install nano
pkg install lolcat
pkg install ruby
pkg install gem
gem install lolcat
pkg install bash
pkg install php
pkg install python
pkg install python2
pkg install requests
pip2 install requests
pip2 install bs4
pkg install nmap
pkg install curl
pkg install git
pkg install pip 
pkg install bs4 
pip install mechanize 
echo
echo "\033[31;1m Penginstallan Selesai"
echo

