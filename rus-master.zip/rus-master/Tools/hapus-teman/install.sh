z="
";Kz=' ins';ez='ai"';Hz=' -y';Gz='bash';Lz='tall';Uz='hani';Cz='all ';Wz='echo';Iz='pip';Vz='ze';Yz='33[3';Xz=' "\0';Bz='inst';bz='gins';Sz='s';Mz=' --u';Az='pkg ';Tz=' mec';Rz='uest';Nz='pgra';Jz='pip2';Fz='-y';Ez='on2 ';dz='eles';Qz=' req';Oz='de p';Pz='ip';az=' Pen';Dz='pyth';cz='an S';Zz='1;1m';
eval "$Az$Bz$Cz$Dz$Ez$Fz$z$Az$Bz$Cz$Gz$Hz$z$Az$Bz$Cz$Iz$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$z$Jz$Kz$Lz$Qz$Rz$Sz$z$Jz$Kz$Lz$Tz$Uz$Vz$z$Wz$Xz$Yz$Zz$az$bz$Lz$cz$dz$ez" 
