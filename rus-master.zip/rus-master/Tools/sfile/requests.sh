z="
";Cz='all ';Az='pkg ';Bz='inst';Gz='grep';Ez='wget';Dz='bash';Fz=' -y';
eval "$Az$Bz$Cz$Dz$z$Az$Bz$Cz$Ez$Fz$z$Az$Bz$Cz$Gz$Fz"